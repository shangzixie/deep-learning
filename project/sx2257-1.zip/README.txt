Youtube link: https://youtu.be/4lLfr9x2wE8
github link: https://github.com/shangzixie/deep-learning